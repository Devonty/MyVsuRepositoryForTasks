package testAtt2;

import java.util.Locale;

import static testAtt2.task5.solve;

public class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        solve(6);
    }
}