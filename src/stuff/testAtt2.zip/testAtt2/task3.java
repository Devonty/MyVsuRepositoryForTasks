package testAtt2;

public class task3 {
    public static int solve(int n) {
        int i = (n) / 3;
        int aN = i + (n % 3) * 5;
        return aN;
    }
}
