package ru.cs.vsu.task_8_27;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;


public class TableFrame extends JFrame {
    private JTextField inputPathTF;
    private JButton inputSubmitButton;
    private JLabel inputLabel;
    private JButton outputSubmitButton;
    private JTextField outputPathTF;
    private JLabel outputLabel;
    private JTable table;
    private JPanel mainPanel;
    private JLabel statusLabel;

    private int[][] matrix;

    public TableFrame() {
        setContentPane(mainPanel);
        setTitle("Table");
        setSize(650, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        inputSubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                // clear status
                statusLabel.setText("");
                // try to read file
                int[][] matrix;
                try {
                    String path = inputPathTF.getText();
                    matrix = Utils.readIntMatrixFromFile(path);
                } catch (IOException e){
                    statusLabel.setText("Ошибка чтения!");
                    return;
                }
                // file data check
                if (matrix.length == 0){
                    statusLabel.setText("Файл пуст!");
                    return;
                }

                // sizes
                int rows = matrix.length;
                int cols = matrix[0].length;

                // prepare table
                DefaultTableModel dtm = (DefaultTableModel) table.getModel();
                dtm.setRowCount(rows);
                dtm.setColumnCount(cols);

                // write in table
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < cols; j++) {
                        dtm.setValueAt(matrix[i][j], i, j);
                    }
                }

                table.setModel(dtm);
                statusLabel.setText("Успешно импотрирован!");
            }
        });
        outputSubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                // clear status
                statusLabel.setText("");

                String path = outputPathTF.getText();



                // sizes
                int rows = table.getRowCount();
                int cols = table.getColumnCount();

                int[][] matrix = new int[rows][cols];

                // write in table
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < cols; j++) {
                        Object nm = table.getModel().getValueAt(i, j);
                        matrix[i][j] = Integer.parseInt(nm.toString());
                    }
                }
                // write to file
                try{
                    Utils.writeIntMatrixToFile(path, matrix);
                }catch (IOException e){
                    e.printStackTrace();
                    statusLabel.setText("Ошибка сохранения!");
                }
                statusLabel.setText("Успешно сохранен!");
            }
        });
    }

    public static void main(String[] args) {
        TableFrame tableFrame = new TableFrame();
    }
}
