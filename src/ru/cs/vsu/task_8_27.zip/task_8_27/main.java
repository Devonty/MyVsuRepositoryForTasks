package ru.cs.vsu.task_8_27;

import java.io.IOException;

public class main {
    public static void main(String[] args) throws IOException {
        FileInfo fileInfo = new FileInfo(args);

        Utils.writeIntMatrixToFile(fileInfo.getOutputPath(), Utils.readIntMatrixFromFile(fileInfo.getInputPath()));
    }
}
